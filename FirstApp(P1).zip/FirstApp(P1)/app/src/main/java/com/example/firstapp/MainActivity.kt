package com.example.firstapp


import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private var currentImage = 0
    lateinit var image : ImageView
    var places =  arrayOf("Derawan Island", "Menara Effiel", "Petra", "Raja Ampat")



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val next = findViewById<ImageButton>(R.id.btnNext)
        val prev = findViewById<ImageButton>(R.id.btnPrev)
        val placeName = findViewById<TextView>(R.id.tvName)


        next.setOnClickListener{
            var idCurrentImageString =  "pic$currentImage"
            var idCurrentImageInt = this.resources.getIdentifier(idCurrentImageString,"id",packageName)
            image = findViewById(idCurrentImageInt)
            image.alpha =0F

            currentImage = (4+currentImage+1)%4
            var idImagetoShowString = "pic$currentImage"
            var idImageToShowInt = this.resources.getIdentifier(idImagetoShowString,"id",packageName)
            image = findViewById(idImageToShowInt)
            image.alpha =1F

            placeName.text = places[currentImage]

        }

        prev.setOnClickListener{
            var idCurrentImageString =  "pic$currentImage"
            var idCurrentImageInt = this.resources.getIdentifier(idCurrentImageString,"id",packageName)
            image = findViewById(idCurrentImageInt)
            image.alpha =0f

            currentImage = (4+currentImage-1)%4
            var idImagetoShowString = "pic$currentImage"
            var idImageToShowInt = this.resources.getIdentifier(idImagetoShowString,"id",packageName)
            image = findViewById(idImageToShowInt)
            image.alpha =1f

        }
    }
}