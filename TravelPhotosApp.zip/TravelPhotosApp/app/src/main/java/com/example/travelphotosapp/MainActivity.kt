package com.example.travelphotosapp

import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    var currentImage = 0
    lateinit var image : ImageView
    var places = arrayOf("Derawan Island","Menara Eiffel", "PETRA", "Raja Ampat")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val next = findViewById<ImageButton>(R.id.btnNext)
        val prev = findViewById<ImageButton>(R.id.btnPrev)
        val placeName = findViewById<TextView>(R.id.tvName)


        next.setOnClickListener{
            var idCurrentImageString =  "pic$currentImage"
            var idCurrentImageInt = this.resources.getIdentifier(idCurrentImageString,"id",packageName)
            image = findViewById(idCurrentImageInt)
            image.alpha =0F

            currentImage = (5+currentImage+1)%5
            var idImagetoShowString = "pic"+currentImage
            var idImagetoshowInt = this.resources.getIdentifier(idImagetoShowString,"id",packageName)
            image = findViewById(idImagetoshowInt)
            image.alpha =1F

            placeName.text= places[currentImage]

        }

        prev.setOnClickListener{
            var idCurrentImageString =  "pic$currentImage"
            var idCurrentImageInt = this.resources.getIdentifier(idCurrentImageString,"id",packageName)
            image = findViewById(idCurrentImageInt)
            image.alpha =0F

            currentImage = (5+currentImage-1)%5
            var idImagetoShowString = "pic"+currentImage
            var idImagetoshowInt = this.resources.getIdentifier(idImagetoShowString,"id",packageName)
            image = findViewById(idImagetoshowInt)
            image.alpha =1F

        }
    }
}