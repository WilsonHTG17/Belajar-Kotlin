package com.example.musicapp

class Artist {
}