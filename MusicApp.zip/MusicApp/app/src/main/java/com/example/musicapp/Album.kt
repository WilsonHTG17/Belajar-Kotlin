package com.example.musicapp

class Album {
}