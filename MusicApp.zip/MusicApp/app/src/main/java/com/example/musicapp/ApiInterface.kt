package com.example.musicapp

import retrofit2.Call

class ApiInterface {
    fun getData(): Call<List<MyData>>
}