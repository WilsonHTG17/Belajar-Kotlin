fun main(){
    println("Helo World")
    test()
}

fun test(){
    println("Learning is fun and rewarding")
}