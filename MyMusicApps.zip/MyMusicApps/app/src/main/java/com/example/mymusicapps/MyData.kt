package com.example.mymusicapps

data class MyData(
    val `data`: List<Data>,
    val next: String,
    val total: Int
)